console.log("Hello, World!");

var h1 = document.getElementById("title")

h1.textContent = 'Hello, World!';